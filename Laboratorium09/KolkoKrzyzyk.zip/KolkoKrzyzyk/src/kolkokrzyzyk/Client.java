package kolkokrzyzyk;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Client implements Runnable {
    private Socket clientSocket;
    private ObjectInputStream inputStream;
    private ObjectOutputStream outputStream;
    private LogikaGry logikaGry;
    private NewJFrame newJFrameInstance;
    private List<ObjectOutputStream> clients;

    private volatile boolean running = true;

    public Client(Socket clientSocket, ObjectOutputStream outputStream, List<ObjectOutputStream> clients) {
        this.clientSocket = clientSocket;
        this.outputStream = outputStream;
        this.clients = Collections.synchronizedList(clients);
    }

    @Override
    public void run() {
        try {
            // Initialize GUI
            newJFrameInstance = new NewJFrame();
            logikaGry = newJFrameInstance.getLogikaGry();

            inputStream = new ObjectInputStream(clientSocket.getInputStream());

            while (running) {
                Serializable receivedMessage = (Serializable) inputStream.readObject();

                if (receivedMessage instanceof Integer) {
                    int numerPrzycisku = (Integer) receivedMessage;
                    logikaGry.wykonajRuch(numerPrzycisku);
                }

                synchronized (clients) {
                    for (ObjectOutputStream client : clients) {
                        try {
                            client.writeObject(logikaGry);
                            client.flush();
                        } catch (IOException e) {
                            // Handle the exception or remove the client if needed
                            e.printStackTrace();
                            clients.remove(client);
                        }
                    }
                }
            }
        } catch (IOException | ClassNotFoundException e) {
            // Handle exceptions if needed
            if (running) {
                e.printStackTrace();
            }
        } finally {
            try {
                if (inputStream != null) {
                    inputStream.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
            synchronized (clients) {
                clients.remove(outputStream);
            }
            try {
                clientSocket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public static void main(String[] args) {
        try (Socket socket = new Socket("localhost", 5455);
             ObjectOutputStream outputStream = new ObjectOutputStream(socket.getOutputStream())) {

            //List<ObjectOutpuStream> clients = Collections.synchronizedList(new ArrayList<>());
            //clients.add(outputStream);

            //Client client = new Client(socket, outputStream, clients);
            //new Thread(client).start();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

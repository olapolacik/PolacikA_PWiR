package kolkokrzyzyk;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.List;

public class ClientHandler implements Runnable {
    private ObjectOutputStream outputStream;
    private List<ObjectOutputStream> clients;

    public ClientHandler(ObjectOutputStream outputStream, List<ObjectOutputStream> clients) {
        this.outputStream = outputStream;
        this.clients = clients;
    }

    @Override
    public void run() {
        try {
            // Initialize GUI for this client
            NewJFrame newJFrameInstance = new NewJFrame();
            LogikaGry logikaGry = newJFrameInstance.getLogikaGry();

            ObjectInputStream inputStream = new ObjectInputStream(outputStream.getClass().getResourceAsStream("localhost"));

            while (true) {
                Serializable receivedMessage = (Serializable) inputStream.readObject();

                if (receivedMessage instanceof Integer) {
                    int numerPrzycisku = (Integer) receivedMessage;
                    logikaGry.wykonajRuch(numerPrzycisku);
                }

                synchronized (clients) {
                    for (ObjectOutputStream client : clients) {
                        try {
                            client.writeObject(logikaGry);
                            client.flush();
                        } catch (IOException e) {
                            // Handle the exception or remove the client if needed
                            e.printStackTrace();
                            clients.remove(client);
                        }
                    }
                }
            }
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
}

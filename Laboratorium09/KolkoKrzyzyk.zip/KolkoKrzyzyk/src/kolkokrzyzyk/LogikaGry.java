/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package kolkokrzyzyk;

import javax.swing.JButton;

/**
 *
 * @author Ola
 */

public interface LogikaGry {
    void wykonajRuch(int indeks);
    //boolean czyGraSieSkonczyla();
    JButton getButton(int index);
}
